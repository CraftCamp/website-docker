<?php

return [
    [
        'id' => 1,
        'name' => 'Site officiel DevelopTech',
        'slug' => 'site-officiel-developtech',
        'product_owner_id' => 1,
        'beta_test_status' => 'closed',
        'nb_beta_testers' => 0,
        'created_at' => '2016-07-01'
    ]
];
