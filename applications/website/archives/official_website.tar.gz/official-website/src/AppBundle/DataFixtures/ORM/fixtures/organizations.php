<?php

return [
    [
        'id' => 1,
        'name' => 'Site officiel de DevelopTech',
        'slug' => 'site-officiel-de-developtech',
        'description' =>
            'Création du site de DevelopTech, comportant les fonctionnalités nécessaires pour la communauté de développeurs ' .
            'autant que pour les associations clientes pour qui l\'association travaillera bénévolement',
        'created_at' => '2016-07-01',
        'updated_at' => '2016-07-01'
    ]
];
