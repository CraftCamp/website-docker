<?php

namespace AppBundle\Repository\User;

use Doctrine\ORM\EntityRepository;

class ActivationLinkRepository extends EntityRepository {

}
